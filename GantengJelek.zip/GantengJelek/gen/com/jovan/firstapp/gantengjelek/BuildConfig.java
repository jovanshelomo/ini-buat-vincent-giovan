/** Automatically generated file. DO NOT MODIFY */
package com.jovan.firstapp.gantengjelek;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}