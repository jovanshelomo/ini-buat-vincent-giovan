package com.jovan.firstapp.gantengjelek;

import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.util.*;
import java.io.*;

public class GantengJelekActivity extends Activity
{
	private Button mGOBtn;
	private TextView mTextTv;
	private EditText mTextEt;
	private Button mGANTENG;
	private Button mJELEK;

    // Called when the activity is first created.
    @Override
    public void onCreate(Bundle savedInstanceState)
	{
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);



		// Get the control instances from the main.xml layout

        mGOBtn = (Button)findViewById(R.id.goBtn);
        mTextTv = (TextView)findViewById(R.id.textTV);
        mTextEt = (EditText)findViewById(R.id.textET);
        mGANTENG = (Button)findViewById(R.id.ganteng);
        mJELEK = (Button)findViewById(R.id.jelek);



		// Assign a click listener to our GO button

        mGOBtn.setOnClickListener(new View.OnClickListener()
			{

				@Override
				public void onClick(View arg0) 
				{

					// Change the text of the textview

					//bikin random ganteng sm jeleknya

					if(new Random().nextInt(2)+1==1){
						mTextTv.setText(mTextEt.getText()+" ganteng!");

					}else{
						mTextTv.setText(mTextEt.getText()+" jelek!");

					}
				}
			});



		mGANTENG.setOnClickListener(new View.OnClickListener()
			{

				@Override
				public void onClick(View arg0)
				{
					mTextTv.setText(mTextEt.getText()+" ganteng! (dipaksa)");
				}
			});
			
		mGANTENG.setOnLongClickListener(new View.OnLongClickListener()
			{

				@Override
				public boolean onLongClick(View arg0)
				{
					mTextTv.setText(mTextEt.getText()+" ganteng banget!");
					return true;
				}
			});

		mJELEK.setOnClickListener(new View.OnClickListener()
			{

				@Override
				public void onClick(View arg0)
				{
					mTextTv.setText(mTextEt.getText()+" jelek! (dipaksa)");
				}
			});
			
		mJELEK.setOnLongClickListener(new View.OnLongClickListener()
			{

				@Override
				public boolean onLongClick(View arg0)
				{
					mTextTv.setText(mTextEt.getText()+" jelek banget!");
					return true;
				}
			});



	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate main_menu.xml 
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.layout.main_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.mainMenuAbout:
				Toast toast = Toast.makeText(this, "Made by Jovan Shelomo", Toast.LENGTH_SHORT);
				toast.setGravity(Gravity.CENTER_VERTICAL,0,0);
				toast.show();
				return true;

			case R.id.mainMenuExit:
				finish();
				return true;
		}
		return super.onOptionsItemSelected(item);
    }



}

